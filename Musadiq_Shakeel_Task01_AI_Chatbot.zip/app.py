import os
from fastapi import FastAPI
from openai import OpenAI
from dotenv import load_dotenv
from fastapi.responses import HTMLResponse

load_dotenv()
app = FastAPI()

# Make sure your .env has GROQ_API_KEY
client = OpenAI(
    base_url="https://api.groq.com/openai/v1",
    api_key=os.getenv("GROQ_API_KEY")
)

# Start with a fresh history
chat_history = [{"role": "system", "content": "You are a professional AI assistant."}]

@app.get("/", response_class=HTMLResponse)
async def get_ui():
    with open("index.html", "r") as f:
        return f.read()

@app.post("/reset")
async def reset_history():
    global chat_history
    chat_history = [{"role": "system", "content": "You are a professional AI assistant."}]
    return {"status": "success"}

@app.get("/chat")
async def chat(msg: str):
    global chat_history
    try:
        chat_history.append({"role": "user", "content": msg})
        
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=chat_history
        )
        
        ai_reply = response.choices[0].message.content
        chat_history.append({"role": "assistant", "content": ai_reply})
        return {"response": ai_reply}
    except Exception as e:
        print(f"Server Error: {e}") # This shows the error in your VS Code terminal
        return {"response": f"Error: {str(e)}"}

if __name__ == "__main__":
    import uvicorn
    # Make sure port 8000 is definitely free
    uvicorn.run(app, host="127.0.0.1", port=8000)